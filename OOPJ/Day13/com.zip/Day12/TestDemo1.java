package Day12;

class A{
	
}

public class TestDemo1 {

	public static void main(String[] args) {
		
		System.out.println("Welcome java!!!");
	}

}
