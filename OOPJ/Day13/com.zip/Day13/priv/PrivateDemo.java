package Day13.priv;

public class PrivateDemo extends Employee{

	public static void main(String[] args) {
		Employee e = new Employee(50000);
		e.display();
		e.show();
		

	}

}
