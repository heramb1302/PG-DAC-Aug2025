package Day13.pub;
import java.lang.*;
import Day13.priv.Employee;

public class TestDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employee e11 = new Employee(10000);
	}

}
