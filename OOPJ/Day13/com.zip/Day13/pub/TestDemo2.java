package Day13.pub;

import Day13.priv.Employee;

public class TestDemo2 extends Employee{

	public static void main(String[] args) {
		
		Employee e33 = new Employee(25000);
		e33.display();
		

	}

}
