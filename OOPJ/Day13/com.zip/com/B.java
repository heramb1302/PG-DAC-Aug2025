package com;

public class B extends A{

}
