package com.company;

public class EmpSal {

}
