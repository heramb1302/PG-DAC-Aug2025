package com.company;

public class EmpDetails {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
