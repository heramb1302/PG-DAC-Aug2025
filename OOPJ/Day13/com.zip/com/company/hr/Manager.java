package com.company.hr;

public class Manager {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
