package com;


public class Test extends B{

	public static void main(String[] args) {
		System.out.println("Hello!!!!");

	}

}
